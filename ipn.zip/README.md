# Image Processing Network
## Programming Assignment 4

#### Group Number
121

#### Names
Connell Hagen -- hage0686

#### Tested Computer
csel-kh1262-21

#### Changes
- Replaced the process killing line in the `Makefile` with the one from Piazza
- Modified the request queue to match my previous assignement's queue
- Modified the parameters of the send and receive functions

#### Plan
I will construct the client handling thread by making it so that upon receiving
a request, the thread passes the request to another thread in the processing
thread pool, where the new thread accepts that request in a new socket. There 
will be `MAX_THREADS` processing threads, and 1 client handling thread. If all
threads are working, then there will not be a `accept` called.
